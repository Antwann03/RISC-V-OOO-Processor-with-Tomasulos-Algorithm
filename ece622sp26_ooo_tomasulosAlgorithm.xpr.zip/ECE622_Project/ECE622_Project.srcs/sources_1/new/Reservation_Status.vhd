----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/26/2026 04:00:45 PM
-- Design Name: 
-- Module Name: Reservation_Status - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
--File name should be named as Reservation Station
entity Reservation_Status is
  Port (
        clk,reset   :in std_logic;
        -- accepts new instructions from the issue unit
        issueEnable : in std_logic;
        issueTag    : in std_logic_vector(3 downto 0);
        issueOp : in std_logic_vector(6 downto 0);
        issueSrc1Tag:   in std_logic_vector(3 downto 0);
        issueSrc1Val:   in std_logic_vector(31 downto 0);
        issueSrc1Valid: in std_logic;
        issueSrc2Tag:   in std_logic_vector(3 downto 0);
        issueSrc2Val:   in std_logic_vector(31 downto 0);
        issueSrc2Valid: in std_logic;
        full:   out std_logic;
        -- CDB port listening for broadcasts
        cdbTag: in std_logic_vector(3 downto 0);
        cdbValue:   in std_logic_vector(31 downto 0);
        cdbValid:   in std_logic;
        -- execute port broadcasting when ready
        executeTag: out std_logic_vector(3 downto 0);
        executeOp:  out std_logic_vector(6 downto 0);
        executeSrc1Val: out std_logic_vector(31 downto 0);
        executeSrc2Val: out std_logic_vector(31 downto 0);
        executeReady:   out std_logic
         );
end Reservation_Status;

architecture Behavioral of Reservation_Status is
    -- RS struct for entry
    type rsEntry is record
        valid,src1Valid,src2Valid:  std_logic;
        tag,src1Tag,src2Tag:    std_logic_vector(3 downto 0);
        src1Val,src2Val:    std_logic_vector(31 downto 0);
        op: std_logic_vector(6 downto 0);
    end record;
    
    type rsArray is array(0 to 3) of rsEntry;
    signal rsEntries:   rsArray:=(others =>(valid  =>'0',tag    =>"0000",
     op =>"0000000",src1Tag    =>"0000",src1Valid  =>'0',src1Val  =>x"00000000",
     src2Tag    =>"0000",src2Valid  =>'0',src2Val  =>x"00000000")
     );
    signal head: integer range 0 to 3   := 0;
    signal count:   integer range 0 to 4    := 0;
    
begin
    rsProcess: process(clk,reset)
    variable next_head: integer range 0 to 3;
    begin
        if reset = '1' then
            rsEntries <= (others=>(valid=>'0',tag=>"0000",op=>"0000000",
            src1Tag=>"0000",src1Valid  =>'0',src1Val=>x"00000000",
            src2Tag=>"0000",src2Valid  =>'0',src2Val  =>x"00000000")
            );
        head    <= 0;
        count   <=0;
        elsif rising_edge(clk) then
        --snoop CDB on all entries;
        --Every cycle, checks all 4 RS entries. If any operated tag matches CDB broadcast, capture the value
        for i in 0 to 3 loop
            if rsEntries(i).valid = '1' and cdbValid = '1' then
            --check if src1 matches with CDB tag
                if rsEntries(i).src1Valid = '0' and rsEntries(i).src1Tag = cdbTag then
                    rsEntries(i).src1Val <= cdbValue;
                    rsEntries(i).src1Valid  <= '1';
                end if;
             --check if src1 matches with CDB tag
                if rsEntries(i).src2Valid = '0' and rsEntries(i).src2Tag = cdbTag then
                    rsEntries(i).src2Val <= cdbValue;
                    rsEntries(i).src2Valid  <= '1';
                end if;
             end if;
         end loop;
         --issueing new inst if space is available
         -- Add instruction at head pointer, move head foward
         if issueEnable = '1' and count < 4 then
         rsEntries(head).valid  <= '1';
         rsEntries(head).tag    <= issueTag;
         rsEntries(head).op     <= issueOp;
         rsEntries(head).src1Tag    <= issueSrc1Tag;
         rsEntries(head).src1Val    <= issueSrc1Val;
         rsEntries(head).src1Valid  <= issueSrc1Valid;
         rsEntries(head).src2Tag    <= issueSrc2Tag;
         rsEntries(head).src2Val    <= issueSrc2Val;
         rsEntries(head).src2Valid  <= issueSrc2Valid;
         head   <= (head+1) mod 4;
         count  <=  count+1;
         end if;
         
         -- if instruction executed, clear it
         
         if executeReady = '1' then
            rsEntries(0).valid  <= '0';
            --After execute we shift down, removed executed instruction, shift reamins ones foward
            for i in 0 to 2 loop
                rsEntries(i)    <= rsEntries(i+1);
            end loop;
            rsEntries(3).valid  <= '0';
            count   <=count-1;
         end if;
         end if;
     end process;
     --check if first entry is ready to execute;
     --First entry (index 0) broadcasts when both operands are ready.
     executeReady   <= '1' when(
        rsEntries(0).valid = '1' and rsEntries(0).src1Valid = '1' and 
        rsEntries(0).src2Valid = '1') else '0';
     --broadcast first entry if ready
     executeTag <= rsEntries(0).tag;
     executeOp  <= rsEntries(0).op;
     executeSrc1Val <= rsEntries(0).src1Val;
     executeSrc2Val <= rsEntries(0).src2Val;
     
     --considers to be that when full reaches 4 slots occupied its full
     full   <= '1' when count = 4 else '0';
end Behavioral;

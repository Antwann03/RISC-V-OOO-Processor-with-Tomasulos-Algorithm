----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 05:23:28 PM
-- Design Name: 
-- Module Name: TOP - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TOP is
  Port (clk, reset: in std_logic;
        instructionInput:   in std_logic_vector(31 downto 0);
        instructionValid:   in std_logic);
end TOP;

architecture Behavioral of TOP is
--COMPONENTS OF EACH VHDL FILE:
-- such Register_File_32,RAT,Instruction Queue, Reservation_Status,ALU,MEM_Unit,CDB,ROB
--COMPONENT FOR REGISTER_FILE_32
component Register_File_32 is
  Port (
        clk:    in std_logic;
        reset:  in std_logic;
        --Requires 2 Write ports 
        --Write Port 1
        RegWrite1:  in std_logic;
        WriteReg1:  in std_logic_vector(4 downto 0);
        WriteData1: in std_logic_vector(31 downto 0);
        --Write Port 2
        RegWrite2:  in std_logic;
        WriteReg2:  in std_logic_vector(4 downto 0);
        WriteData2: in std_logic_vector(31 downto 0);
        
        --Read Port 1
        ReadReg1:   in std_logic_vector(4 downto 0);
        ReadData1:  out std_logic_vector(31 downto 0);
        --Read Port 2
        ReadReg2: in std_logic_vector(4 downto 0);
        ReadData2: out std_logic_vector(31 downto 0)
         );
end component;
--COMPONENT for RAT
component RAT is
  Port (
    clk, reset: in std_logic;
    --Tag Destination Register
    WriteEnable:    in std_logic;
    WriteRegister:  in std_logic_vector(4 downto 0);
    WriteTag:   in std_logic_vector(3 downto 0);
    
    --Clear Tag When ROB commits
    ClearEnable:    in std_logic;
    ClearRegister:  in std_logic_vector(4 downto 0);
    
    --Port 1: LookUpSource Register 1
    ReadReg1:   in std_logic_vector(4 downto 0);
    Tag1:   out std_logic_vector(3 downto 0);
    Valid1: out std_logic;
    --Port 2: LooKUpSoruce Register 2
    ReadReg2:   in std_logic_vector(4 downto 0);
    Tag2:   out std_logic_vector(3 downto 0);
    Valid2: out std_logic
    );
end component;
--COMPONENT INSTRUCTION QUEUE
component Instruction_Queue is
  Port (
        clk,reset,enqueue,dequeue:  in std_logic;
        instruction_in: in std_logic_vector(31 downto 0);
        full,empty: out std_logic;
        instruction_out:    out std_logic_vector(31 downto 0)
        );
end component;
--COMPONENT RESERVATION_STATUS -- this is supposed to be the reservation station
component Reservation_Status is
  Port (
        clk,reset   :in std_logic;
        -- accepts new instructions from the issue unit
        issueEnable : in std_logic;
        issueTag    : in std_logic_vector(3 downto 0);
        issueOp : in std_logic_vector(6 downto 0);
        issueSrc1Tag:   in std_logic_vector(3 downto 0);
        issueSrc1Val:   in std_logic_vector(31 downto 0);
        issueSrc1Valid: in std_logic;
        issueSrc2Tag:   in std_logic_vector(3 downto 0);
        issueSrc2Val:   in std_logic_vector(31 downto 0);
        issueSrc2Valid: in std_logic;
        full:   out std_logic;
        -- CDB port listening for broadcasts
        cdbTag: in std_logic_vector(3 downto 0);
        cdbValue:   in std_logic_vector(31 downto 0);
        cdbValid:   in std_logic;
        -- execute port broadcasting when ready
        executeTag: out std_logic_vector(3 downto 0);
        executeOp:  out std_logic_vector(6 downto 0);
        executeSrc1Val: out std_logic_vector(31 downto 0);
        executeSrc2Val: out std_logic_vector(31 downto 0);
        executeReady:   out std_logic
         );
end component;
--COMPONENT FOR ALU
component ALU is
  Port (
        executeSrc1Val: in std_logic_vector(31 downto 0);
        executeSrc2Val: in std_logic_vector(31 downto 0);
        executeOp:  in std_logic_vector(6 downto 0);
        aluResult:  out std_logic_vector(31 downto 0));
end component;
--COMPONENT FOR MEM_UNIT
component MEM_Unit is
  Port (
        --memValid  notifies when the operation is valid
        clk,reset,memValid: in std_logic;
        --executeSrc1Val is for the base address
        executeSrc1Val: in std_logic_vector(31 downto 0);
        --executeSrc2Val is for the data to store (for SW)
        executeSrc2Val: in std_logic_vector(31 downto 0);
        --executeOp is for LW or SW opcode
        executeOp:  in std_logic_vector(6 downto 0);
        --Read/Write for simu memory
        --Load data for LW
        memResult:  out std_logic_vector(31 downto 0);
        --memReady is for operation completed
        memReady:   out std_logic);
end component;
--COMPONENT FOR CDB
component CDB is
  Port (
        clk, reset: in std_logic;
        --ALU/MEM inputs
        aluValid,memValid:  in std_logic;
        aluTag,memTag:  in std_logic_vector(3 downto 0);
        aluResult,memResult:    in std_logic_vector(31 downto 0);
        -- CDB broadcast outputs
        cdbValid:   out std_logic;
        cdbTag: out std_logic_vector(3 downto 0 );
        cdbVal: out std_logic_vector(31 downto 0)
         );
end component;
--COMPONENT FOR ROB
component ROB is
  Port (
        clk,reset:  in std_logic;
        --Enqueue part; accept new instruction
        enqueueEnable:  in std_logic;
        enqueueDestinationReg:  in std_logic_vector(4 downto 0);
        robTag: out std_logic_vector(3 downto 0);
        full:   out std_logic;
        --CDB Input Part: Listen for completed instructions
        cdbValid:   in std_logic;
        cdbTag: in std_logic_vector(3 downto 0);
        cdBVal: in std_logic_vector(31 downto 0);
        --Commit Part: retire new instruction at head
        commitEnable:   out std_logic;
        commitDestinationReg:   out std_logic_vector(4 downto 0);
        commitResult:   out std_logic_vector(31 downto 0)
        );
end component;

--SIGNALS:

--Instruction_Queue signals
signal iqInstruction:   std_logic_vector(31 downto 0);
signal iqEmpty,iqFull:  std_logic;
--RAT signals
signal ratTag1,ratTag2: std_logic_vector(3 downto 0);
signal ratValid1,ratValid2: std_logic;
--Reservation Status(reservation station) signals
signal rsExecuteTag:    std_logic_vector(3 downto 0);
signal rsExecuteOp: std_logic_vector(6 downto 0);
signal rsExecuteSrc1Val,rsExecuteSrc2Val: std_logic_vector(31 downto 0);
signal rsExecuteReady,rsFull:  std_logic;
--ALU signals
signal aluResult:   std_logic_vector(31 downto 0);
signal aluValid:    std_logic;
--MEM signals
signal memResult:   std_logic_vector(31 downto 0);
signal memValid, memReady:  std_logic;
--CDB signals
signal cdbVal:  std_logic_vector(31 downto 0);
signal cdbTag:  std_logic_vector(3 downto 0);
signal cdbValid:    std_logic;
--ROB signals
signal robTag:  std_logic_vector(3 downto 0);
signal robFull: std_logic;
--COMMIT signals
signal commitResult:    std_logic_vector(31 downto 0);
signal commitDestinationReg:    std_logic_vector(4 downto 0);
signal commitEnable:    std_logic;
--RF signals
signal rfReadData1,rfReadData2: std_logic_vector(31 downto 0);
--signal declationt for OOO-execution
signal issueCounter: integer range 0 to 3:=0;
signal issueEnableInternal: std_logic:='0';
signal enqueueEnableInternal: std_logic:='0';
signal ratWriteEnable: std_logic:='0';
signal ratClearEnable: std_logic:='0';
begin
--Instruction Queue
IQ_instantiation: Instruction_Queue
    port map(
            clk=>clk,reset=>reset,enqueue=>instructionValid,
            instruction_in=>instructionInput,dequeue=>'0',
            instruction_out=>iqInstruction,full=>iqFull,empty=>iqEmpty);
            
--Register File
RF_instantiation: Register_File_32
    port map(
            clk=>clk,reset=>reset,RegWrite1=>commitEnable,WriteReg1=>commitDestinationReg,
            WriteData1=>commitResult,RegWrite2=>'0',WriteReg2=>"00000",WriteData2=>x"00000000",
            ReadReg1=>iqInstruction(19 downto 15),ReadReg2=>iqInstruction(24 downto 20),
            ReadData1=>rfReadData1,ReadData2=>rfReadData2);
--RAT - Register Alias Table
RAT_instantiation: RAT
    port map(
            clk=>clk,reset=>reset,WriteEnable=>ratWriteEnable,WriteRegister=>"00000",WriteTag=>"0000",
            clearEnable=>ratClearEnable,clearRegister=>"00000",
            ReadReg1=>iqInstruction(19 downto 15),ReadReg2=>iqInstruction(24 downto 20),
            Tag1=>ratTag1,Tag2=>ratTag2,Valid1=>ratValid1,Valid2=>ratValid2);
--Reservation Status ->Reservation Stations       
RS_instantiation: Reservation_Status
    port map(
            clk=>clk,reset=>reset,issueEnable=> issueEnableInternal, issueTag=>robTag,
            issueOp=>iqInstruction(6 downto 0),issueSrc1Tag=>ratTag1,
            issueSrc1Val=>rfReadData1,issueSrc1Valid=>not ratValid1,
            issueSrc2Tag=>ratTag2,issueSrc2Val=>rfReadData2,issueSrc2Valid=> not ratValid2,
            full=>rsFull,cdbTag=>cdbTag,cdbValue=>cdbVal,cdbValid=>cdbValid,
            executeTag=>rsExecuteTag,executeOp=>rsExecuteOp,
            executeSrc1Val=>rsExecuteSrc1Val,executeSrc2Val=>rsExecuteSrc2Val,
            executeReady=>rsExecuteReady);
--ALU
ALU_instantiation: ALU
    port map(
            executeSrc1Val=>rsExecuteSrc1Val,executeSrc2Val=>rsExecuteSrc2Val,
            executeOp=>rsExecuteOp,aluResult=>aluResult);
            --ALU is valid when execute ready
            aluValid<=rsExecuteReady;
--MEM UNIT
MEM_instantiation: MEM_Unit
    port map(
            clk=>clk,reset=>reset,executeSrc1Val=>rsExecuteSrc1Val,executeSrc2Val=>rsExecuteSrc2Val,
            executeOp=>rsExecuteOp,memValid=>'0',memResult=>memResult,memReady=>memReady);
            memValid <= memReady;
            
--CDB
CDB_instantiation: CDB
    port map(
        clk=>clk,reset=>reset, aluValid=>aluValid,aluTag=>rsExecuteTag,aluResult=>aluResult,
        memValid=>memValid,memTag=>rsExecuteTag,memResult=>memResult, 
        cdbValid=>cdbValid,cdbTag=>cdbTag,cdbVal=>cdbVal);
--ROB
ROB_instantiation: ROB
    port map(
        clk=>clk,reset=>reset,enqueueEnable=>enqueueEnableInternal,enqueueDestinationReg=>iqInstruction(11 downto 7),
        robTag=>robTag,full=>robFull,cdbValid=>cdbValid,cdbTag=>cdbTag,cdbVal=>cdbVal,
        commitEnable=>commitEnable,commitDestinationReg=>commitDestinationReg,commitResult=>commitResult);         
--CONTROL LOGIC ** MAIN PART
process(clk,reset)
begin 
    if reset='1' then
        issueCounter <= 0;
        issueEnableInternal <= '0';
        enqueueEnableInternal   <= '0';
        ratWriteEnable  <= '0';
        ratClearEnable  <= '0';
    elsif rising_edge(clk) then
        --issue one instruction every 2 cycles if IQ is not empty, RS notfull, ROB not full
        if issueCounter = 0 and iqEmpty ='0' and rsFull = '0' and robFull ='0' then
            issueEnableInternal <= '1';
            enqueueEnableInternal <= '1';
            ratWriteEnable  <= '1';
        elsif issueCounter > 0 then
            issueEnableInternal <= '0';
            enqueueEnableInternal   <='0';
            ratWriteEnable  <= '0';
            issueCounter <= issueCounter+1;
            if issueCounter = 2 then
                issueCounter <= 0;
            end if;
         else
            issueEnableInternal <= '0';
            enqueueEnableInternal   <= '0';
            ratWriteEnable  <='0';
         end if;
         --Clear RAT when ROB commits
         ratClearEnable <=commitEnable;
     end if;
end process;
end Behavioral;

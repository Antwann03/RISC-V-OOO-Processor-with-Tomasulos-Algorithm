----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/20/2026 10:14:20 AM
-- Design Name: 
-- Module Name: RAT - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity RAT is
  Port (
    clk, reset: in std_logic;
    --Tag Destination Register
    WriteEnable:    in std_logic;
    WriteRegister:  in std_logic_vector(4 downto 0);
    WriteTag:   in std_logic_vector(3 downto 0);
    
    --Clear Tag When ROB commits
    ClearEnable:    in std_logic;
    ClearRegister:  in std_logic_vector(4 downto 0);
    
    --Port 1: LookUpSource Register 1
    ReadReg1:   in std_logic_vector(4 downto 0);
    Tag1:   out std_logic_vector(3 downto 0);
    Valid1: out std_logic;
    --Port 2: LooKUpSoruce Register 2
    ReadReg2:   in std_logic_vector(4 downto 0);
    Tag2:   out std_logic_vector(3 downto 0);
    Valid2: out std_logic
    );
end RAT;

architecture Behavioral of RAT is
    type EntryRAT is record
    tag:    std_logic_vector(3 downto 0);
    valid:  std_logic;
    end record;
    
    type ArrayRAT is array(0 to 31) of EntryRAT;
    signal TableOfRAT:  ArrayRAT := (others =>(tag =>"0000", valid => '0'));
begin

    RATProcess: process(clk,reset)
    begin
        if reset = '1' then
            TableOfRAT <= (others =>(tag =>"0000", valid =>'0'));
        elsif rising_edge(clk) then
        if ClearEnable = '1' then
            if ClearRegister /= "00000" then
            TableOfRAT(to_integer(unsigned(ClearRegister))).valid <= '0';
            TableOfRat(to_integer(unsigned(ClearRegister))).tag <= "0000";
            end if;
        end if;
        
        if WriteEnable = '1' then
            if WriteRegister /= "00000" then
            TableOfRAT(to_integer(unsigned(WriteRegister))).tag <= WriteTag;
            TableOfRAT(to_integer(unsigned(WriteRegister))).valid <= '1';
            end if;
        end if;
        end if;
        end process;
        
        --Asynch Read
        Tag1    <= TableOfRAT(to_integer(unsigned(ReadReg1))).tag;
        Tag2    <= TableOfRAT(to_integer(unsigned(ReadReg2))).tag;
        Valid1  <= TableOfRAT(to_integer(unsigned(ReadReg1))).valid;
        Valid2  <= TableOfRAT(to_integer(unsigned(ReadReg2))).valid;
end Behavioral;

----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/28/2026 03:18:38 PM
-- Design Name: 
-- Module Name: D_FF - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
/*
entity defines the interface, what goes in and out. Function signature

*/
entity D_FF is
  Port ( 
  clk: in std_logic;
  reset: in std_logic;
  D: in std_logic;
  Q: out std_logic);
end D_FF;
/*
Defines what the hardware actually does
*/
architecture Behavioral of D_FF is
begin
/*
This block runs whenever clock or reset changes
-- Q only updates at the rising edge, holds otherwise
*/
process(clk, reset)
begin
    if reset = '1' then
    /*
    <=   : Assignment of Signals
    :=   : Assignment of Variables and Signal Initialization
    */
    Q <= '0';
    elsif rising_edge(clk) then
    Q <= D;
    end if;
    end process;

end Behavioral;

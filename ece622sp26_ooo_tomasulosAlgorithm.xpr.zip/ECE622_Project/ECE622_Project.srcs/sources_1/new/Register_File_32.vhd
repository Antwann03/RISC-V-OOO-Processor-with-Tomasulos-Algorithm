----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/19/2026 07:29:29 PM
-- Design Name: 
-- Module Name: Register_File_32 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Register_File_32 is
  Port (
        clk:    in std_logic;
        reset:  in std_logic;
        --Requires 2 Write ports 
        --Write Port 1
        RegWrite1:  in std_logic;
        WriteReg1:  in std_logic_vector(4 downto 0);
        WriteData1: in std_logic_vector(31 downto 0);
        --Write Port 2
        RegWrite2:  in std_logic;
        WriteReg2:  in std_logic_vector(4 downto 0);
        WriteData2: in std_logic_vector(31 downto 0);
        
        --Read Port 1
        ReadReg1:   in std_logic_vector(4 downto 0);
        ReadData1:  out std_logic_vector(31 downto 0);
        --Read Port 2
        ReadReg2: in std_logic_vector(4 downto 0);
        ReadData2: out std_logic_vector(31 downto 0)
         );
end Register_File_32;

architecture Behavioral of Register_File_32 is
    type registerArray is array(0 to 31) of std_logic_vector(31 downto 0);
    signal registers: registerArray := (others =>(others=> '0'));
begin
    WriteProcess: process(clk, reset)
    begin
    if reset = '1' then
        registers <= (others => (others => '0'));
        
        elsif rising_edge(clk) then
        --Write Port 1
        if RegWrite1 = '1' then
        -- /= not equal to
            if WriteReg1 /= "00000" then
            --Converting 00001 to 1, where it becomes registers(1) <= WriteData1
            registers(to_integer(unsigned(WriteReg1))) <= WriteData1;
            end if;
        end if;
        --Write Port 2
        if RegWrite2 = '1' then
            if WriteReg2 /= "00000" then
            registers(to_integer(unsigned(WriteReg2))) <= WriteData2;
            end if;
        end if;
        
     end if;
     end process;

ReadData1 <= registers(to_integer(unsigned(ReadReg1)));
ReadData2 <= registers(to_integer(unsigned(ReadReg2)));
end Behavioral;

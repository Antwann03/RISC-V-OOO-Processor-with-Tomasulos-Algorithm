library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CDB is
  Port (
        clk, reset: in std_logic;
        --ALU/MEM inputs
        aluValid,memValid:  in std_logic;
        aluTag,memTag:  in std_logic_vector(3 downto 0);
        aluResult,memResult:    in std_logic_vector(31 downto 0);
        -- CDB broadcast outputs
        cdbValid:   out std_logic;
        cdbTag: out std_logic_vector(3 downto 0 );
        cdbVal: out std_logic_vector(31 downto 0)
         );
end CDB;

architecture Behavioral of CDB is

begin

cdbProcess:
process(clk, reset)
    begin
        if reset = '1' then
            cdbValid <= '0';
            cdbTag  <= "0000";
            cdbVal  <= (others =>'0');
        elsif rising_edge(clk) then
            --Priorty: ALU will take priorty over MEM if BOTH are valid
            if aluValid = '1' then
                cdbValid <= '1';
                cdbTag <= aluTag;
                cdbVal  <= aluResult;
            elsif memValid = '1' then
                cdbValid <= '1';
                cdbTag  <= memTag;
                cdbVal  <= memResult;
            else
                cdbValid    <= '0';
                cdbTag  <= "0000";
                cdbVal  <= (others=>'0');
             end if;
        end if;
end process;
end Behavioral;
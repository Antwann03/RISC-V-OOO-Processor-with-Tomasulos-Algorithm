----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/27/2026 08:27:43 PM
-- Design Name: 
-- Module Name: MEM_Unit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity MEM_Unit is
  Port (
        --memValid  notifies when the operation is valid
        clk,reset,memValid: in std_logic;
        --executeSrc1Val is for the base address
        executeSrc1Val: in std_logic_vector(31 downto 0);
        --executeSrc2Val is for the data to store (for SW)
        executeSrc2Val: in std_logic_vector(31 downto 0);
        --executeOp is for LW or SW opcode
        executeOp:  in std_logic_vector(6 downto 0);
        --Read/Write for simu memory
        --Load data for LW
        memResult:  out std_logic_vector(31 downto 0);
        --memReady is for operation completed
        memReady:   out std_logic);
end MEM_Unit;

architecture Behavioral of MEM_Unit is
    -- 256 words of 32-bit memory, pre-initialized with some values
    type memArray is array (0 to 255) of std_logic_vector(31 downto 0);
    signal memory: memArray:=(
        0=>x"00000001",1=>x"00000002",2=>x"00000003",3=>x"00000004",4=>x"00000005",
        others =>x"00000000");
    signal opInProgress:    std_logic:= '0';
    signal pendingResult:   std_logic_vector(31 downto 0):=(others=>'0');
    
begin
    memProcess:
    process(clk,reset)
        variable addr:  integer range 0 to 255;
    begin
        if reset = '1' then 
            opInProgress <= '0';
            memReady    <= '0';
            pendingResult   <= (others=>'0');
        elsif rising_edge(clk) then
        -- if operation has just completed, then clear ready
            if opInProgress = '1' then
                memReady    <= '1';
                opInProgress <= '0';
            else
            memReady    <= '0';
            end if;
            -- if new requests arrives
            if memReady <= '1' then 
            --Uses lower 8 bits od address (gives us 256 addressable locations)
            addr:= to_integer(unsigned(executeSrc1Val(7 downto 0)));
            -- LW(load word): opcode is 0000011 - read from memory
                if executeOp = "0000011" then
                    pendingResult<= memory(addr);
                    opInProgress <= '1';
            -- SW(Store word): opcode is 0100011 - write to memory
                elsif executeOp = "0100011" then
                    memory(addr)    <= executeSrc2Val;
                    opInProgress    <= '1';
                end if;
            end if;
        end if;
    end process;
    memResult   <=pendingResult;
end Behavioral;

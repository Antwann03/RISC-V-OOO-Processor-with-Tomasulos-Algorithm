----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/28/2026 03:26:00 PM
-- Design Name: 
-- Module Name: ROB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ROB is
  Port (
        clk,reset:  in std_logic;
        --Enqueue part; accept new instruction
        enqueueEnable:  in std_logic;
        enqueueDestinationReg:  in std_logic_vector(4 downto 0);
        robTag: out std_logic_vector(3 downto 0);
        full:   out std_logic;
        --CDB Input Part: Listen for completed instructions
        cdbValid:   in std_logic;
        cdbTag: in std_logic_vector(3 downto 0);
        cdBVal: in std_logic_vector(31 downto 0);
        --Commit Part: retire new instruction at head
        commitEnable:   out std_logic;
        commitDestinationReg:   out std_logic_vector(4 downto 0);
        commitResult:   out std_logic_vector(31 downto 0)
        );
end ROB;

architecture Behavioral of ROB is
--ROB entry struct
    type robEntry is record
        valid   : std_logic;
        done    : std_logic;
        destinationReg  : std_logic_vector(4 downto 0);
        result  : std_logic_vector(31 downto 0);
    end record;
--ROB 8-entry
    type robArray is array(0 to 7) of robEntry;
    signal robTable: robArray:=(others=>(valid=>'0',done=>'0',destinationReg=>"00000",result=>x"00000000"));
-- pointers for the header and tail
    signal head:    integer range 0 to 7    :=0;
    signal tail:    integer range 0 to 7    :=0;
--keep in count of how many entires are occupied; tracking
signal count:   integer range 0 to 8 := 0;

begin

robProcess:
process(clk,reset)
begin
    if reset = '1' then
        robTable    <= (others =>(valid=>'0',done=>'0',destinationReg=>"00000",result=>x"00000000"));
        head    <= 0;
        tail    <= 0;
        count   <= 0;
    elsif rising_edge(clk) then
--Mark instruction done if the tag matches
--Every cycle, check all 8 ROB entries. If CDB tag matches an entry index, mark it done and store the result
        if cdbValid = '1' then
        for i in 0 to 7 loop
            if robTable(i).valid = '1' and robTable(i).done = '0' then
                if i = to_integer(unsigned(cdbTag)) then
                    robTable(i).done <= '1'; 
                    robTable(i).result  <= cdbVal;
                end if;
            end if;
         end loop;
    end if;
--enqueue new instructions if space available
--new instruction goes to tail slot
    if enqueueEnable = '1' and count < 8 then
        robTable(tail).valid    <= '1';
        robTable(tail).done <= '0';
        robTable(tail).destinationReg   <= enqueueDestinationReg;
        robTable(tail).result   <= x"00000000";
        tail <= (tail+1) mod 8;
        count <= count+1;
    end if;
    --if instruction at head is done, clear it and move head forward
    if robTable(head).valid = '1' and robTable(head).done = '1' then
        robTable(head).valid <= '0';
        head    <= (head+1) mod 8;
        count <= count-1;
    end if;
    
    end if;
end process;
--output current ROB tag for new instruction
--Tell the issuer which ROB entry this instruction gets
robTag  <=std_logic_vector(to_unsigned(tail,4));
--output head instruction if ready
commitEnable    <= '1' when (robTable(head).valid = '1' and robTable(head).done = '1') else '0';
commitDestinationReg    <= robTable(head).destinationReg;
commitResult   <= robTable(head).result;

full    <= '1' when count = 8 else '0';
end Behavioral;

    ----------------------------------------------------------------------------------
    -- Company: 
    -- Engineer: 
    -- 
    -- Create Date: 03/28/2026 10:59:32 PM
    -- Design Name: 
    -- Module Name: FIFO - Behavioral
    -- Project Name: 
    -- Target Devices: 
    -- Tool Versions: 
    -- Description: 
    -- 
    -- Dependencies: 
    -- 
    -- Revision:
    -- Revision 0.01 - File Created
    -- Additional Comments:
    -- 
    ----------------------------------------------------------------------------------
    
    
    library IEEE;
    use IEEE.STD_LOGIC_1164.ALL;
    
    -- Uncomment the following library declaration if using
    -- arithmetic functions with Signed or Unsigned values
    use IEEE.NUMERIC_STD.ALL;
    
    -- Uncomment the following library declaration if instantiating
    -- any Xilinx leaf cells in this code.
    --library UNISIM;
    --use UNISIM.VComponents.all;
    
    entity FIFO is
      port (clk, reset,WriteEnable,ReadEnable: in std_logic;
            DataIn: in std_logic_vector(31 downto 0);
            DataOut: out std_logic_vector(31 downto 0);
            full, empty: out std_logic
            );
    end FIFO;
    
    architecture Behavioral of FIFO is
    
    type FIFOArray is array (0 to 3) of std_logic_vector(31 downto 0);
    signal FIFOMemory: FIFOArray := (others =>(others=> '0'));
    --pointers for heads and tails
    signal head,tail:integer range 0 to 3 := 0;
    --tracking the amount of entry that are used
    signal count: integer range 0 to 4 := 0;
    
    begin
    FIFOProcess: process(clk, reset)
    begin 
    if reset = '1' then
    head <= 0;
    tail <= 0;
    count <=0;
    FIFOMemory <= (others =>(others=>'0'));
     -- mod 4 is the wrap around when the its already done.
     -- once tail reaches 3 and you add 'mod 4' BRINGS it BACK to 0
    elsif rising_edge(clk) then
    if WriteEnable = '1' and count < 4 then
    FIFOMemory(tail) <= DataIn;
    tail <= (tail+1) mod 4;
    count <= count +1;
    end if;
    
    if ReadEnable = '1' and count > 0 then
    head <= (head+1) mod 4;
    count <= count -1;
    end if;
    end if;
    end process;
     -- Combinational output; it WILL show whatever the head pointer is at
    DataOut <= FIFOMemory(head);
    
    full <= '1' when count = 4 else '0';
    empty <= '1' when count = 0 else '0';
    end Behavioral;

----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/27/2026 07:21:33 PM
-- Design Name: 
-- Module Name: ALU - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU is
  Port (
        executeSrc1Val: in std_logic_vector(31 downto 0);
        executeSrc2Val: in std_logic_vector(31 downto 0);
        executeOp:  in std_logic_vector(6 downto 0);
        aluResult:  out std_logic_vector(31 downto 0));
end ALU;

architecture Behavioral of ALU is
begin
    --no clock; this is purely combinational. Any chnage to inputs immediately updates output.
    process(executeSrc1Val,executeSrc2Val,executeOp)
    begin
    --Each opcode will map to a different operation
        case executeOp is
        --Converted to unsigned, do the mathm convert back to std_logic_vector
        --ADD opcode is 0110011
            when "0110011" =>aluResult<=std_logic_vector(unsigned(executeSrc1Val)+ unsigned(executeSrc2Val));
        --SUB opcode is 0110011
            when "0110010" =>aluResult<=std_logic_vector(unsigned(executeSrc1Val)- unsigned(executeSrc2Val));
        --AND opcode is 0110011
            when "0110001" =>aluResult<=std_logic_vector(unsigned(executeSrc1Val)and unsigned(executeSrc2Val));
        --OR opcode is 0110011
            when "0110000" =>aluResult<=std_logic_vector(unsigned(executeSrc1Val)or unsigned(executeSrc2Val));
        --XOR opcode is 0110011
            when "0101111" =>aluResult<=std_logic_vector(unsigned(executeSrc1Val)xor unsigned(executeSrc2Val));
        --ADDI opcode is 0110011
            when "0010011" =>aluResult<=std_logic_vector(unsigned(executeSrc1Val)+ unsigned(executeSrc2Val));
        -- for SLT, use signed comparison
        --SLT opcode is 0110011
            when "0101110" =>
            if signed(executeSrc1Val)< signed(executeSrc2Val) then
            aluResult <= x"0000_0001";
            else
            aluResult <= x"0000_0000";
            end if;
            
            when others =>
            aluResult <= (others =>'0');
         end case;
     end process;  
end Behavioral;

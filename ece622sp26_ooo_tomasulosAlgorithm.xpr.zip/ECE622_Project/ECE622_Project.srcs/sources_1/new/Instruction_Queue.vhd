----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/20/2026 08:51:36 PM
-- Design Name: 
-- Module Name: Instruction_Queue - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Instruction_Queue is
  Port (
        clk,reset,enqueue,dequeue:  in std_logic;
        instruction_in: in std_logic_vector(31 downto 0);
        full,empty: out std_logic;
        instruction_out:    out std_logic_vector(31 downto 0)
        );
end Instruction_Queue;

architecture Behavioral of Instruction_Queue is
    --8instructions queue entry
    type instruction_queueArray is array(0 to 7) of std_logic_vector(31 downto 0);
    signal queueMemory: instruction_queueArray := (others=> (others=>'0'));
    --H/T pointers
    signal head:    integer range 0 to 7:=0;
    signal tail:    integer range 0 to 7:=0;  
    --Tracking amount of entries are used
    signal count:   integer range 0 to 8:=0;
    
begin
    proceessQueue: process(clk,reset)
    begin
        if reset = '1' then
        head    <=0;
        tail    <=0;
        count   <=0;
        queueMemory <=(others =>(others=>'0'));
     elsif rising_edge(clk) then
     
         if enqueue = '1' and count < 8 then
         queueMemory(tail) <= instruction_in;
         tail   <= (tail+1) mod 8;
         count <= count+1;
         end if;
         if dequeue = '1' and count > 0 then
         head   <=(head+1) mod 8;
         count <= count-1;
         end if;
     end if;
     end process;
     instruction_out    <= queueMemory(head);
     
     full   <= '1' when count = 8 else '0';
     empty  <= '1' when count = 0 else '0';
end Behavioral;

----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/28/2026 07:11:35 PM
-- Design Name: 
-- Module Name: Register_File - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
--Entity: Inputs and Outputs for Interface
entity Register_File is
  Port (clk, reset: in std_logic;
  --Write portion
  RegWrite: in std_logic;
  WriteReg: in std_logic_vector(2 downto 0);
  WriteData: in std_logic_vector(31 downto 0);
  
  --Reading Data Portions 
  ReadReg1: in std_logic_vector(2 downto 0);
  ReadData1: out std_logic_vector(31 downto 0);
  ReadReg2: in std_logic_vector(2 downto 0);
  ReadData2: out std_logic_vector(31 downto 0)
  );
  
end Register_File;

architecture Behavioral of Register_File is
--The signals and types MUST be declared
-- There is 8 rows from 0 to 7 top to bottom. Where EACH rows contains 32 bits each.
-- Index 0 = Register 0, Index 1 = Register 1 ... etc
type RegisterListArray is array(0 to 7) of std_logic_vector(31 downto 0);
-- Outer part of "others" fills the 8 slots; Inner part of "Others" fills all 32 bits each slot with 0
signal registers :RegisterListArray := (others => (others =>'0'));

begin
WriteProcess: process(clk,reset)
begin
if reset = '1' then
registers <= (others => (others=>'0'));
elsif rising_edge(clk) then
if RegWrite = '1' then
if WriteReg /= "000" then
registers(to_integer(unsigned(WriteReg))) <= WriteData;
end if;
end if;
end if;
end process;
ReadData1 <= registers(to_integer(unsigned(ReadReg1)));
ReadData2 <= registers(to_integer(unsigned(ReadReg2)));
end Behavioral;

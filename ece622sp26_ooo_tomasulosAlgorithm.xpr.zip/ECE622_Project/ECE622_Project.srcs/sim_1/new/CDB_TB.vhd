----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/27/2026 11:38:40 PM
-- Design Name: 
-- Module Name: CDB_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CDB_TB is
--  Port ( );
end CDB_TB;

architecture Behavioral of CDB_TB is
component CDB is
  Port (
        clk, reset: in std_logic;
        --ALU/MEM inputs
        aluValid,memValid:  in std_logic;
        aluTag,memTag:  in std_logic_vector(3 downto 0);
        aluResult,memResult:    in std_logic_vector(31 downto 0);
        -- CDB broadcast outputs
        cdbValid:   out std_logic;
        cdbTag: out std_logic_vector(3 downto 0 );
        cdbVal: out std_logic_vector(31 downto 0)
         );
end component;

--TB signals
signal clk_TB, reset_TB,aluValid_TB,memValid_TB: std_logic:= '0';
signal aluTag_TB,memTag_TB: std_logic_vector(3 downto 0):="0000";
signal aluResult_TB,memResult_TB: std_logic_vector(31 downto 0):= (others=>'0');
signal cdbValid_TB: std_logic;
signal cdbTag_TB:  std_logic_vector(3 downto 0);
signal cdbVal_TB:  std_logic_vector(31 downto 0);
begin
    UUT: CDB
    port map(
            clk=>clk_TB, reset=>reset_TB,aluValid=>aluValid_TB,memValid=>memValid_TB,
            aluTag=>aluTag_TB,memTag=>memTag_TB,aluResult=>aluResult_TB,memResult=>memResult_TB,
            cdbValid=>cdbValid_TB,cdbTag=>cdbTag_TB,cdbVal=>cdbVal_TB);
    clkProcess:
    process
        begin
            clk_TB  <= '0';
            wait for 10 ns;
            clk_TB  <= '1';
            wait for 10 ns;
    end process;
    
    simu_process:
    process
        begin
            --reset
            reset_TB    <= '1';
            wait for 20 ns;
            reset_TB    <= '0';
            wait for 20 ns;
            --ALU broadcast result
            aluValid_TB <= '1';
            aluTag_TB   <= "0001";
            aluResult_TB    <= x"00000010";
            wait for 20 ns;
            --STOP ALU broadcast
            aluValid_TB <= '0';
            wait for 20 ns;
            --MEM broadcast result
            memValid_TB <= '1';
            memTag_TB   <= "0010";
            memResult_TB    <= x"00000020";
            wait for 20 ns;
            --STOP MEM broadcast
            memValid_TB <= '0';
            wait for 20 ns;
            --ALU vs MEM; ALU should be TOP priority
            aluValid_TB <= '1';
            aluTag_TB   <= "0011";
            aluResult_TB    <= x"00000030";
            memValid_TB <= '1';
            memTag_TB   <= "0100";
            memResult_TB    <= x"00000040";
            wait for 20 ns;
            --only mem VALID now
            aluValid_TB <= '0';
            wait for 20 ns;
            --stop both alu and mem
            memValid_TB <= '0';
            wait for 20 ns;
            --ALU with diff tag and val
            aluValid_TB <= '1';
            aluTag_TB   <= "0111";
            aluResult_TB    <= x"AAAAAAAA";
            wait for 20 ns;
            --MEM with diff tag and val
            aluValid_TB <= '0';
            memValid_TB <= '1';
            memTag_TB   <= "1000";
            memResult_TB    <=x"BBBBBBBB";
            wait for 20 ns;
            memValid_TB <= '0';
            wait for 20 ns;
            wait;
    end process;
end Behavioral;

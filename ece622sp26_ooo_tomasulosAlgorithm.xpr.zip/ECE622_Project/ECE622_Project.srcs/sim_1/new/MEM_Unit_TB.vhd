----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/27/2026 08:51:12 PM
-- Design Name: 
-- Module Name: MEM_Unit_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity MEM_Unit_TB is
--  Port ( );
end MEM_Unit_TB;

architecture Behavioral of MEM_Unit_TB is
component MEM_Unit is
  Port (
        --memValid  notifies when the operation is valid
        clk,reset,memValid: in std_logic;
        --executeSrc1Val is for the base address
        executeSrc1Val: in std_logic_vector(31 downto 0);
        --executeSrc2Val is for the data to store (for SW)
        executeSrc2Val: in std_logic_vector(31 downto 0);
        --executeOp is for LW or SW opcode
        executeOp:  in std_logic_vector(6 downto 0);
        --Read/Write for simu memory
        --Load data for LW
        memResult:  out std_logic_vector(31 downto 0);
        --memReady is for operation completed
        memReady:   out std_logic);
end component;
--TB SIGNALS
signal clk_TB,reset_TB,memValid_TB: std_logic := '0';
signal executeSrc1Val_TB,executeSrc2Val_TB: std_logic_vector(31 downto 0) := (others => '0');
signal executeOp_TB:    std_logic_vector(6 downto 0):= "0000000";
signal memResult_TB:    std_logic_vector(31 downto 0);
signal memReady_TB:    std_logic;
begin
    UUT: MEM_Unit
    port map(
            clk=>clk_TB,reset=>reset_TB,memValid=>memValid_TB,memResult=>memResult_TB,memReady=>memReady_TB,
            executeSrc1Val=>executeSrc1Val_TB, executeSrc2Val=>executeSrc2Val_TB,executeOp=>executeOp_TB);
    clk_process:
    process
    begin
        clk_TB  <= '0';
        wait for 10 ns;
        clk_TB  <= '1';
        wait for 10 ns;
    end process;
    simu_process:
    process
    begin
     reset_TB   <= '1';
     wait for 20 ns;
     reset_TB   <= '0';
     wait for 20 ns;   
    -- LW from addres 0; should return 0x00000001
        memValid_TB <= '1';
        executeSrc1Val_TB   <= x"00000000";
        executeOp_TB    <= "0000011";
        wait for 20 ns;
     -- the results should be ready now
     memValid_TB    <= '0';
     wait for 20 ns;
     -- LW from address 2; should return 0x00000003
     memValid_TB    <= '1';
     executeSrc1Val_TB  <=  x"00000002";
     executeOp_TB   <= "0000011";
     wait for 20 ns;
     -- results should be ready now
     memValid_TB    <= '0';
     wait for 20 ns;
     --SW to addr 5 with value 0xdeadbeef
     memValid_TB    <= '1';
     executeSrc1Val_TB  <= x"00000005";
     executeSrc2Val_TB  <= x"DEADBEEF";
     executeOp_TB   <= "0100011";
     wait for 20 ns;
     --LW from addr 5 should return 0xdeadbeef from what we jsut wrote
     memValid_TB    <= '1';
     executeSrc1Val_TB  <= x"00000005";
     executeOp_TB   <= "0000011";
     wait for 20 ns;
     -- result should be ready now with the stored value
     memValid_TB    <= '0';
     wait for 20 ns;
     --SW to addr 1 with value 0xcafebabe
     memValid_TB    <= '1';
     executeSrc1Val_TB  <= x"00000001";
     --data to store
     executeSrc2Val_TB  <= x"CAFEBABE";
     executeOp_TB   <= "0100011";
     wait for 20 ns;
     --LW from addr 1 to verify store did work
     memValid_TB    <= '1';
     executeSrc1Val_TB  <= x"00000001";
     executeOp_TB   <= "0000011";
     wait for 20 ns;
     memValid_TB    <= '0';
     wait for 20 ns;
        
        wait;
    end process;
end Behavioral;

    ----------------------------------------------------------------------------------
    -- Company: 
    -- Engineer: 
    -- 
    -- Create Date: 04/18/2026 06:17:16 PM
    -- Design Name: 
    -- Module Name: FIFO_TB - Behavioral
    -- Project Name: 
    -- Target Devices: 
    -- Tool Versions: 
    -- Description: 
    -- 
    -- Dependencies: 
    -- 
    -- Revision:
    -- Revision 0.01 - File Created
    -- Additional Comments:
    -- 
    ----------------------------------------------------------------------------------
    
    library IEEE;
    use IEEE.STD_LOGIC_1164.ALL;
    
    -- Uncomment the following library declaration if using
    -- arithmetic functions with Signed or Unsigned values
    use IEEE.NUMERIC_STD.ALL;
    
    -- Uncomment the following library declaration if instantiating
    -- any Xilinx leaf cells in this code.
    --library UNISIM;
    --use UNISIM.VComponents.all;
    
    entity FIFO_TB is
    --  Port ( );
    end FIFO_TB;
    
    architecture Behavioral of FIFO_TB is
    component FIFO
    port (clk, reset,WriteEnable,ReadEnable: in std_logic;
          DataIn: in std_logic_vector(31 downto 0);
          DataOut: out std_logic_vector(31 downto 0);
          full, empty: out std_logic);
    end component;
    signal clk_TB,reset_TB, WriteEnable_TB, ReadEnable_TB : std_logic := '0';
    signal DataIn_TB: std_logic_vector(31 downto 0) := (others =>'0');
    signal DataOut_TB:std_logic_vector(31 downto 0);
    signal full_TB,empty_TB: std_logic;
    begin
    
    UUT: FIFO
    port map (
    clk =>clk_TB,reset=>reset_TB, WriteEnable=>WriteEnable_TB,
    ReadEnable=>ReadEnable_TB, DataIn=>DataIn_TB, DataOut=>DataOut_TB,
    full=>full_TB, empty=>empty_TB);
    
    process_clock: process
    begin
    clk_TB <= '0';
    wait for 10 ns;
    clk_TB <= '1';
    wait for 10 ns;
    end process;
    
    process_simu:process
    begin
    reset_TB <= '1';
    wait for 20 ns;
    reset_TB <= '0';
    wait for 20 ns;
    

    -- Writting 4 values to fill the FIFO
    WriteEnable_TB <= '1';
    DataIn_TB <= x"00000001";
    wait for 20 ns;

    DataIn_TB <= x"00000002";
    wait for 20 ns;

    DataIn_TB <= x"00000003";
    wait for 20 ns;

    DataIn_TB <= x"00000004";
    wait for 20 ns;

-- TEST 3 ; expectation should be that its FULL
    DataIn_TB <= x"000000FF";
    wait for 20 ns;
    
    -- TEST 4; Start reading the values
    WriteEnable_TB <= '0';
    ReadEnable_TB <= '1';
    wait for 20 ns;
    --read 2
    wait for 20 ns;
    --read 3
    wait for 20 ns;
    -- read 4
    wait for 20 ns;
    -- read 5 (should be skipped or ignored)
    wait for 20 ns;
    
    -- writing and reading at the same time
    WriteEnable_TB <= '1';
    ReadEnable_TB <= '1';
    DataIn_TB <= x"0000AAAA";
    wait for 20 ns;
    
    DataIn_TB <= x"0000BBBB";
    wait for 20 ns;
    wait;
    
    end process;
    
    end Behavioral;

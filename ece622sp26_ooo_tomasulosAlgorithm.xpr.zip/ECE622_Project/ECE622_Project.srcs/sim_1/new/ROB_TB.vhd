----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/28/2026 04:01:32 PM
-- Design Name: 
-- Module Name: ROB_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ROB_TB is
--  Port ( );
end ROB_TB;

architecture Behavioral of ROB_TB is
component ROB
  Port (
        clk,reset:  in std_logic;
        --Enqueue part; accept new instruction
        enqueueEnable:  in std_logic;
        enqueueDestinationReg:  in std_logic_vector(4 downto 0);
        robTag: out std_logic_vector(3 downto 0);
        full:   out std_logic;
        --CDB Input Part: Listen for completed instructions
        cdbValid:   in std_logic;
        cdbTag: in std_logic_vector(3 downto 0);
        cdBVal: in std_logic_vector(31 downto 0);
        --Commit Part: retire new instruction at head
        commitEnable:   out std_logic;
        commitDestinationReg:   out std_logic_vector(4 downto 0);
        commitResult:   out std_logic_vector(31 downto 0)
        );
end component;
--TB singals
signal clk_TB,reset_TB,enqueueEnable_TB,cdbValid_TB:    std_logic:='0';
signal enqueueDestinationReg_TB:    std_logic_vector(4 downto 0):="00000";
signal commitDestinationReg_TB: std_logic_vector(4 downto 0);
signal cdbTag_TB    : std_logic_vector(3 downto 0):="0000";
signal robTag_TB    : std_logic_vector(3 downto 0);
signal cdbVal_TB    : std_logic_vector(31 downto 0):=(others=>'0');
signal commitResult_TB    : std_logic_vector(31 downto 0);
signal full_TB,commitEnable_TB  : std_logic;

begin

    UUT: ROB
    port map(
            clk=>clk_TB,reset=>reset_TB,enqueueEnable=>enqueueEnable_TB,cdbValid=>cdbValid_TB,
            enqueueDestinationReg=>enqueueDestinationReg_TB,commitDestinationReg=>commitDestinationReg_TB,
            cdbTag=>cdbTag_TB,robTag=>robTag_TB,cdbVal=>cdbVal_TB,commitResult=>commitResult_TB,
            full=>full_TB,commitEnable=>commitEnable_TB);
    clkProcess:
    process
    begin
        clk_TB  <= '0';
        wait for 10 ns;
        clk_TB  <= '1';
        wait for 10 ns;
    end process;
    
    simuProcess:
    process
    begin
    reset_TB    <= '1';
    wait for 20 ns;
    reset_TB    <= '0';
    wait for 20 ns;
    --enqueue instruction to x1
    enqueueEnable_TB    <= '1';
    enqueueDestinationReg_TB    <= "00001";
    wait for 20 ns;
    --enqueue instruction to x2
    enqueueDestinationReg_TB    <= "00010";
    wait for 20 ns;
    --enqueue instruction to x3
    enqueueDestinationReg_TB    <= "00011";
    wait for 20 ns;
    --STOP enqueueing, CDB broadcast result for ROB0 (x1)
    enqueueEnable_TB    <= '0';
    cdbValid_TB <= '1';
    cdbTag_TB   <= "0000";
    cdbVal_TB   <= x"00000010";
    wait for 20 ns;
    --instruction at head ROB0 should now commit
    cdbValid_TB <= '0';
    wait for 20 ns;
    --CDB broadcast result for ROB1 (x2)
    cdbValid_TB  <= '1';
    cdbTag_TB   <= "0001";
    cdbVal_TB   <= x"00000020";
    wait for 20 ns;
    --ROB1 should commit
    cdbValid_TB <= '0';
    wait for 20 ns;
    --CDB broadcast results for ROB2 (x3)
    cdbValid_TB <= '1';
    cdbTag_TB   <= "0011";
    cdbVal_TB   <= x"00000030";
    wait for 20 ns;
    --ROB2 should commit
    cdbValid_TB <= '0';
    wait for 20 ns;
    --enqueue 8 instructions to fill ROB
    enqueueEnable_TB    <= '1';
    enqueueDestinationReg_TB    <= "00001";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "00010";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "00011";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "00100";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "00101";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "00110";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "00111";
    wait for 20 ns;
    enqueueDestinationReg_TB    <= "01000";
    wait for 20 ns;
    --ROB is full now
    enqueueEnable_TB    <= '0';
    wait for 20 ns;
    -- TRYING to enqueue one more; should be ignored
    enqueueEnable_TB    <= '1';
    enqueueDestinationReg_TB    <= "00110";
    wait for 20 ns;
    enqueueEnable_TB    <= '0';
    wait;
    end process;
end Behavioral;

----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/19/2026 08:12:07 PM
-- Design Name: 
-- Module Name: Register_File_32_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Register_File_32_TB is
--  Port ( );
end Register_File_32_TB;

architecture Behavioral of Register_File_32_TB is
component Register_File_32 is
  port (
        clk:    in std_logic;
        reset:  in std_logic;
        --Requires 2 Write ports 
        --Write Port 1
        RegWrite1:  in std_logic;
        WriteReg1:  in std_logic_vector(4 downto 0);
        WriteData1: in std_logic_vector(31 downto 0);
        --Write Port 2
        RegWrite2:  in std_logic;
        WriteReg2:  in std_logic_vector(4 downto 0);
        WriteData2: in std_logic_vector(31 downto 0);
        
        --Read Port 1
        ReadReg1:   in std_logic_vector(4 downto 0);
        ReadData1:  out std_logic_vector(31 downto 0);
        --Read Port 2
        ReadReg2: in std_logic_vector(4 downto 0);
        ReadData2: out std_logic_vector(31 downto 0)
         );
end component;
signal clk_TB, reset_TB, RegWrite1_TB, RegWrite2_TB:    std_logic := '0';
signal WriteReg1_TB,WriteReg2_TB, ReadReg1_TB, ReadReg2_TB:    std_logic_vector(4 downto 0) := "00000";
signal WriteData1_TB, WriteData2_TB:    std_logic_vector(31 downto 0):= (others =>'0');
signal ReadData1_TB, ReadData2_TB:  std_logic_vector(31 downto 0);
begin

UUT: Register_File_32
    port map(
        clk=>clk_TB,reset=>reset_TB, RegWrite1=>RegWrite1_TB, WriteReg1=>WriteReg1_TB,
        WriteData1=>WriteData1_TB, RegWrite2=>RegWrite2_TB,WriteReg2=>WriteReg2_TB,
        WriteData2=>WriteData2_TB, ReadReg1=>ReadReg1_TB, ReadData1=>ReadData1_TB,
        ReadReg2=>ReadReg2_TB, ReadData2=>ReadData2_TB
    );
    
clk_process: process
begin
    clk_TB  <='0';
    wait for 10 ns;
    clk_TB  <='1';
    wait for 10 ns;
    end process;
        
simu_process: process
begin
    reset_TB    <= '1';
    wait for 20 ns;
    reset_TB    <= '0';
    wait for 20 ns;
    --Write to x1 for port 1
    RegWrite1_TB    <= '1';
    WriteReg1_TB    <= "00001";
    WriteData1_TB   <= x"AAAA_AAAA";
    wait for 20 ns;
    --Write to x2 for port 2; simulataneously
    RegWrite2_TB    <= '1';
    WriteReg2_TB    <= "00010";
    WriteData2_TB   <= x"BBBB_BBBB";
    wait for 20 ns;
    --Write to x3 and x4 simultaneously; port 1: x3, port 2: x4
    RegWrite1_TB    <= '1';
    WriteReg1_TB    <= "00011";
    WriteData1_TB   <= x"CCCC_CCCC";
    RegWrite2_TB    <= '1';
    WriteReg2_TB    <= "00100";
    WriteData2_TB   <= x"DDDD_DDDD";
    wait for 20 ns;
    --Read x1 and x2 at the same time
    RegWrite1_TB    <= '0';
    RegWrite2_TB    <= '0';
    ReadReg1_TB <= "00001";
    ReadReg2_TB <= "00010";
    wait for 20 ns;
    --Read x3 and x4 at the same time 
    ReadReg1_TB <= "00011";
    ReadReg2_TB <= "00100";
    wait for 20 ns;
    --Write to x0 for both parts
    RegWrite1_TB    <= '1';
    WriteReg1_TB    <= "00000";
    WriteData1_TB   <= x"DEADBEEF";
    RegWrite2_TB    <= '1';
    WriteReg2_TB    <= "00000";
    WriteData2_TB   <= x"CAFEBABE";
    wait for 20 ns;
    --read x0 where it SHOULD stay at zero
    RegWrite1_TB    <= '0';
    RegWrite2_TB    <= '0';
    ReadReg1_TB <= "00000";
    ReadReg2_TB <= "00000";
    
    wait;
    end process;     
end Behavioral;

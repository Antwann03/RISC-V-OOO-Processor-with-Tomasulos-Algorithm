----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/26/2026 12:21:25 PM
-- Design Name: 
-- Module Name: Instruction_Queue_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Instruction_Queue_TB is
--  Port ( );
end Instruction_Queue_TB;

architecture Behavioral of Instruction_Queue_TB is
component Instruction_Queue is
  Port (
        clk,reset,enqueue,dequeue:  in std_logic;
        instruction_in: in std_logic_vector(31 downto 0);
        full,empty: out std_logic;
        instruction_out:    out std_logic_vector(31 downto 0)
        );
end component;
    signal clk_TB,reset_TB,enqueue_TB,dequeue_TB:   std_logic:='0';
    signal instruction_in_TB:   std_logic_vector(31 downto 0):=(others=>'0');
    signal full_TB, empty_TB:   std_logic;
    signal instruction_out_TB:  std_logic_vector(31 downto 0);
begin
    UUT:Instruction_Queue
    port map(
            clk=>clk_TB,reset=>reset_TB,enqueue=>enqueue_TB, dequeue=>dequeue_TB,
            instruction_in=>instruction_in_TB, full=>full_TB,
            empty=>empty_TB,instruction_out=>instruction_out_TB
            );
    clk_process:
    process
    begin
    clk_TB  <= '0';
    wait for 10 ns;
    clk_TB  <= '1';
    wait for 10 ns;
    end process;

    simu_process:
    process
    begin
    reset_TB    <='1';
    wait for 20 ns;
    reset_TB    <='0';
    wait for 20 ns;
    
    --Enqueue the 8 instructions to fill up the queue
    enqueue_TB  <= '1';
    instruction_in_TB   <= x"0000_0001";    -- ADDI x1, x0, 1
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0002";    -- ADDI x2, x0, 2
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0003";    -- ADDI x3, x0, 3
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0004";    -- ADDI x4, x0, 4
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0005";    -- ADDI x5, x0, 5
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0006";    -- ADDI x6, x0, 6
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0007";    -- ADDI x7, x0, 7
    wait for 20 ns;
    instruction_in_TB   <= x"0000_0008";    -- ADDI x8, x0, 8
    wait for 20 ns;
    
    --Enqueue one more should be ignored since its full now
    instruction_in_TB   <= x"0000_00FF";
    wait for 20 ns;
    
    --Dequeue starts here
    enqueue_TB  <= '0';
    dequeue_TB  <= '1';
    wait for 20 ns; -- dequeing instruction 1
    wait for 20 ns; -- dequeing instruction 2
    wait for 20 ns; -- dequeing instruction 3
    wait for 20 ns; -- dequeing instruction 4
    wait for 20 ns; -- dequeing instruction 5
    wait for 20 ns; -- dequeing instruction 6
    wait for 20 ns; -- dequeing instruction 7
    wait for 20 ns; -- dequeing instruction 8
    
    --queue should be empty here. one more dequeue is attempted and should be ignored
    wait for 20 ns; -- dequeing instruction 1

    --enqueue and dequeue begin at the same time (simultaneously)
    enqueue_TB <= '1';
    dequeue_TB  <=  '1';
    instruction_in_TB   <= x"0000_AAAA";
    wait for 20 ns;
    instruction_in_TB   <= x"0000_BBBB";
    wait for 20 ns;
    wait;
    end process;
end Behavioral;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU_TB is
  --Port ()
end ALU_TB;

architecture Behavioral of ALU_TB is
component ALU is
  Port (
        executeSrc1Val: in std_logic_vector(31 downto 0);
        executeSrc2Val: in std_logic_vector(31 downto 0);
        executeOp:  in std_logic_vector(6 downto 0);
        aluResult:  out std_logic_vector(31 downto 0));
end component;
signal executeSrc1Val_TB,executeSrc2Val_TB: std_logic_vector(31 downto 0) := (others => '0');
signal executeOp_TB:   std_logic_vector(6 downto 0):= "0000000";
signal aluResult_TB:    std_logic_vector(31 downto 0);

begin

UUT: ALU
    port map(
            executeSrc1Val=>executeSrc1Val_TB,executeSrc2Val=>executeSrc2Val_TB,
            executeOp=>executeOp_TB,aluResult=>aluResult_TB);
            
    simu_process:
    process
        begin
            --Test One: ADD part; 5 + 3 = 8
            executeSrc1Val_TB   <= x"00000005";
            executeSrc2Val_TB   <= x"00000003";
            executeOP_TB    <= "0110011";
            wait for 10 ns;
            --Test Two: SUB part; 10 - 4 = 6
            executeSrc1Val_TB   <= x"0000000A";
            executeSrc2Val_TB   <= x"00000004";
            executeOP_TB    <= "0110010";
            wait for 10 ns;
            --Test Three: AND Part; 0xFF00 and 0x00FF = 0x0000
            executeSrc1Val_TB   <= x"0000FF00";
            executeSrc2Val_TB   <= x"000000FF";
            executeOP_TB    <= "0110001";
            wait for 10 ns;
            --Test Four; OR Part; 0xFF00 or 0x00FF = 0xFFFF
            executeSrc1Val_TB   <= x"0000FF00";
            executeSrc2Val_TB   <= x"000000FF";
            executeOP_TB    <= "0110000";
            wait for 10 ns;
            --Test Five; XOR Part; 0xAAAA xor 0x5555 = 0xFFFF
            executeSrc1Val_TB   <= x"0000AAAA";
            executeSrc2Val_TB   <= x"00005555";
            executeOP_TB    <= "0101111";
            wait for 10 ns;
            --Test Six; ADDI Part; 7 + 2 = 9
            executeSrc1Val_TB   <= x"00000007";
            executeSrc2Val_TB   <= x"00000002";
            executeOP_TB    <= "0010011";
            wait for 10 ns;
            --Test Seven; SLT Part True; 3 < 5 = 1 (TRUE)
            executeSrc1Val_TB   <= x"00000003";
            executeSrc2Val_TB   <= x"00000005";
            executeOP_TB    <= "0101110";
            wait for 10 ns;
            --Test Eight; SLT Part False; 5 < 3 = 0 (FALSE)
            executeSrc1Val_TB   <= x"00000005";
            executeSrc2Val_TB   <= x"00000003";
            executeOP_TB    <= "0101110";
            wait for 10 ns;
            --Test Nine; ADD with larger numbers 0x12345678 + 0x87654321
            executeSrc1Val_TB   <= x"12345678";
            executeSrc2Val_TB   <= x"87654321";
            executeOP_TB    <= "0110011";
            wait for 10 ns;
            wait;
      end process;
end Behavioral;
----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/28/2026 04:19:33 PM
-- Design Name: 
-- Module Name: D_FF_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity D_FF_TB is
--  Port ( );
end D_FF_TB;

architecture Behavioral of D_FF_TB is

--Declare function is for the use of creatign a Test Bench
component D_FF
port (clk,reset,D: in std_logic;
      Q: out std_logic);
end component;

signal clk_TB,reset_TB,D_TB: std_logic := '0';
signal Q_TB: std_logic;

begin

UUT: D_FF
port map(clk=>clk_TB, reset =>reset_TB, D=>D_TB, Q=>Q_TB);

clk_process:process
begin
clk_TB <= '0';
wait for 10 ns;
clk_TB <= '1';
wait for 10 ns;
end process;

reset_process:process
begin
-- testing the reset when its at 1; waiting 20 ns
reset_TB <= '1';
wait for 20 ns;

reset_TB <= '0';
D_TB <= '1';
wait for 20 ns;

D_TB <= '0';
wait for 20 ns;

D_TB <= '1';
wait for 20 ns;

reset_TB <= '0';
D_TB <= '1';
wait;
end process;
end Behavioral;

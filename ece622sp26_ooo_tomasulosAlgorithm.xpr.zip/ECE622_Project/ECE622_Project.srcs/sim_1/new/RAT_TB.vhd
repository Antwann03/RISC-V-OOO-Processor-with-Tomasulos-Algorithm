----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/20/2026 10:58:14 AM
-- Design Name: 
-- Module Name: RAT_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity RAT_TB is
--  Port ( );
end RAT_TB;

architecture Behavioral of RAT_TB is
component RAT is
  Port (
    clk, reset: in std_logic;
    --Tag Destination Register
    WriteEnable:    in std_logic;
    WriteRegister:  in std_logic_vector(4 downto 0);
    WriteTag:   in std_logic_vector(3 downto 0);
    
    --Clear Tag When ROB commits
    ClearEnable:    in std_logic;
    ClearRegister:  in std_logic_vector(4 downto 0);
    
    --Port 1: LookUpSource Register 1
    ReadReg1:   in std_logic_vector(4 downto 0);
    Tag1:   out std_logic_vector(3 downto 0);
    Valid1: out std_logic;
    --Port 2: LooKUpSoruce Register 2
    ReadReg2:   in std_logic_vector(4 downto 0);
    Tag2:   out std_logic_vector(3 downto 0);
    Valid2: out std_logic
    );
end component;
    signal Valid1_TB, Valid2_TB:    std_logic;
    signal clk_TB, reset_TB,WriteEnable_TB,ClearEnable_TB: std_logic:= '0';
    signal WriteRegister_TB,ClearRegister_TB,ReadReg1_TB,ReadReg2_TB:   std_logic_vector(4 downto 0):= "00000";
    signal WriteTag_TB,Tag1_TB,Tag2_TB: std_logic_vector(3 downto 0) := "0000";
    
begin

    UUT:RAT
    port map (
    clk =>clk_TB, reset=>reset_TB, WriteEnable=> WriteEnable_TB,
    ClearEnable=>ClearEnable_TB, WriteRegister=>WriteRegister_TB,
    ClearRegister=>ClearRegister_TB,ReadReg1=>ReadReg1_TB, ReadReg2=>ReadReg2_TB,
    WriteTag=>WriteTag_TB, Valid1=>Valid1_TB,Valid2=>Valid2_TB,
    Tag1=>Tag1_TB, Tag2=>Tag2_TB
    );
    
clk_process:
process
    begin
    clk_TB <= '0';
    wait for 10 ns;
    clk_TB <= '1';
    wait for 10 ns;
end process;

simu_process:
process
    begin
    --Reset test1
    reset_TB <= '1';
    wait for 20 ns;
    reset_TB <= '0';
    wait for 20 ns;
    --Tag x1 with ROB3
    WriteEnable_TB  <=  '1';
    WriteRegister_TB    <=  "00001";
    WriteTag_TB <=  "0011";
    wait for 20 ns;
    --Tagx2 with ROB5
    WriteRegister_TB    <=  "00010";
    WriteTag_TB <=  "0101";
    wait for 20 ns;  
    --Read x1 and x2; should show the tag value
    WriteEnable_TB  <=  '0';
    ReadReg1_TB <=  "00001";
    ReadReg2_TB <=  "00010";
    wait for 20 ns; 
    --Tag x3 with ROB7
    WriteEnable_TB  <=  '1';
    WriteRegister_TB <=  "00011";
    WriteTag_TB <=  "0111";
    wait for 20 ns;
    --Read x1,x2,x3; x3 is the new tag incoming
    WriteEnable_TB  <=  '0';
    ReadReg1_TB <=  "00001";
    ReadReg2_TB <=  "00011";
    wait for 20 ns;
    --Clear x1; ROB3 committed
    ClearEnable_TB  <=  '1';
    ClearRegister_TB    <= "00001";
    wait for 20 ns;
    --Read x1 again; valid should be 0
    ClearEnable_TB  <=  '0';
    ReadReg1_TB <=  "00001";
    wait for 20 ns;
    --Tagging x0, should be ignored
    WriteEnable_TB  <=  '1';
    WriteRegister_TB    <=  "00000";
    WriteTag_TB <=  "1111";
    wait for 20 ns;
    --Read x0, valid should be zero still, tag = 0000
    WriteEnable_TB  <= '0';
    ReadReg1_TB <=  "00000";
    wait for 20 ns;
    --Clear Takes PRIORTIY over write
    --tag x4 with ROB2 and clear x2 same cycle
    WriteEnable_TB  <=  '1';
    WriteRegister_TB <=  "00100";
    WriteTag_TB <=  "0010";
    ClearEnable_TB  <=  '1';
    ClearRegister_TB   <=  "00010";
    wait for 20 ns;
    --read x2 and x4. x2 should be cleared and x4 be tagged
    WriteEnable_TB  <= '0';
    ClearEnable_TB  <=  '0';
    ReadReg1_TB <=  "00010";
    ReadReg2_TB <=  "00100";
    wait for 20 ns;
    wait;
end process;

end Behavioral;

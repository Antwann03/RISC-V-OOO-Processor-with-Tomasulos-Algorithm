----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/26/2026 07:42:38 PM
-- Design Name: 
-- Module Name: Reservation_Status_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Reservation_Status_TB is
--  Port ( );
end Reservation_Status_TB;

architecture Behavioral of Reservation_Status_TB is
component Reservation_Status is
  Port (
        clk,reset   :in std_logic;
        -- accepts new instructions from the issue unit
        issueEnable : in std_logic;
        issueTag    : in std_logic_vector(3 downto 0);
        issueOp : in std_logic_vector(6 downto 0);
        issueSrc1Tag:   in std_logic_vector(3 downto 0);
        issueSrc1Val:   in std_logic_vector(31 downto 0);
        issueSrc1Valid: in std_logic;
        issueSrc2Tag:   in std_logic_vector(3 downto 0);
        issueSrc2Val:   in std_logic_vector(31 downto 0);
        issueSrc2Valid: in std_logic;
        full:   out std_logic;
        -- CDB port listening for broadcasts
        cdbTag: in std_logic_vector(3 downto 0);
        cdbValue:   in std_logic_vector(31 downto 0);
        cdbValid:   in std_logic;
        -- execute port broadcasting when ready
        executeTag: out std_logic_vector(3 downto 0);
        executeOp:  out std_logic_vector(6 downto 0);
        executeSrc1Val: out std_logic_vector(31 downto 0);
        executeSrc2Val: out std_logic_vector(31 downto 0);
        executeReady:   out std_logic
         );
end component;
--TB signals
    signal clk_TB,reset_TB,issueEnable_TB,issueSrc1Valid_TB, issueSrc2Valid_TB,cdbValid_TB: std_logic := '0';
    signal issueTag_TB, issueSrc1Tag_TB, issueSrc2Tag_TB,cdbTag_TB: std_logic_vector(3 downto 0) := "0000";
    signal issueSrc1Val_TB,issueSrc2Val_TB,cdbValue_TB:std_logic_vector(31 downto 0) := (others=>'0');
    signal executeSrc1Val_TB,executeSrc2Val_TB: std_logic_vector(31 downto 0);
    signal issueOp_TB: std_logic_vector(6 downto 0) := "0000000";
    signal executeOp_TB:    std_logic_vector(6 downto 0);
    signal executeTag_TB:   std_logic_vector(3 downto 0);
    signal full_TB,executeReady_TB: std_logic;
begin
UUT: Reservation_Status
    port map(
        clk=>clk_TB, reset=>reset_TB, issueEnable=>issueEnable_TB,
        issueSrc1Valid=>issueSrc1Valid_TB,issueSrc2Valid=>issueSrc2Valid_TB,
        issueTag=>issueTag_TB, issueSrc1Tag=>issueSrc1Tag_TB,issueSrc2Tag=>issueSrc2Tag_TB,
        cdbTag=>cdbTag_TB, issueSrc1Val=>issueSrc1Val_TB, issueSrc2Val=>issueSrc2Val_TB,
        cdbValue=>cdbValue_TB,executeSrc1Val=>executeSrc1Val_TB,executeSrc2Val=>executeSrc2Val_TB,
        issueOp=>issueOp_TB, executeOp=>executeOp_TB,executeTag=>executeTag_TB, full=>full_TB,
        executeReady=>executeReady_TB,cdbValid=>cdbValid_TB);
        
    clock_process:
    process
    begin
        clk_TB  <='0';
        wait for 10 ns;
        clk_TB  <= '1';
        wait for 10 ns;
    end process;
    simu_process:
    process
    begin
        reset_TB    <= '1';
        wait for 20 ns;
        reset_TB    <= '0';
        wait for 20 ns;
        --ADD ROB#0, src1 = 10 and src2 = 20
        issueEnable_TB  <= '1';
        issueTag_TB <= "0000";
        issueOp_TB  <= "0000011"; -- ADD inst
        issueSrc1Tag_TB <= "0000";
        issueSrc1Val_TB <= x"0000000A";
        issueSrc1Valid_TB   <= '1';
        issueSrc2Tag_TB <= "0000";
        issueSrc2Val_TB <= x"00000014";
        issueSrc2Valid_TB   <= '1';
        wait for 20 ns;
        --Instruction SHOULD EXECUTE IMMEDIATELY (both operands are ready)
        issueEnable_TB  <= '0';
        wait for 20 ns;
        
        --Issue instruction with one operand waiting for CDB
        --add rob#1, src 1 = 5, src2 waiting for rob#2
        issueEnable_TB  <= '1';
        issueTag_TB <= "0001";
        issueOp_TB  <= "0000011"; --ADD
        issueSrc1Tag_TB <= "0000"; 
        issueSrc1Val_TB <= x"00000005";
        issueSrc1Valid_TB   <= '1';
        issueSrc2Tag_TB <= "0010"; --ROB#2
        issueSrc2Val_TB <= x"00000000";
        issueSrc2Valid_TB   <= '0'; -- is not ready, yet
        wait for 20 ns;
        
        --CDB broadcasts ROB#2 with value 15
        --RS should snoop and complete src2
        issueEnable_TB  <= '0';
        cdbValid_TB <= '1';
        cdbTag_TB   <= "0010";
        cdbValue_TB <= x"0000000F";
        wait for 20 ns;
        
        --instruction should be ready to execute
        cdbValid_TB <= '0';
        wait for 20 ns;
        
        --issue 3 more instructions to test if its full
        issueEnable_TB  <= '1';
        issueTag_TB <= "0010";
        issueSrc1Valid_TB   <= '1';
        issueSrc2Valid_TB   <= '1';
        issueSrc1Val_TB <= x"00000001";
        issueSrc2Val_TB <= x"00000002";
        wait for 20 ns;
        issueTag_TB <= "0011";
        issueSrc1Val_TB <= x"00000003";
        issueSrc2Val_TB <= x"00000004";
        wait for 20 ns;
        issueTag_TB <= "0100";
        issueSrc1Val_TB <= x"00000005";
        issueSrc2Val_TB <= x"00000006";
        wait for 20 ns;
        issueTag_TB <= "0101";
        issueSrc1Val_TB <= x"00000007";
        issueSrc2Val_TB <= x"00000008";
        wait for 20 ns;
    wait;
    end process;

end Behavioral;

----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/28/2026 07:57:23 PM
-- Design Name: 
-- Module Name: Register_File_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Register_File_TB is
--  Port ( );
end Register_File_TB;

architecture Behavioral of Register_File_TB is
component Register_File
port (clk,reset,RegWrite: in std_logic;
      WriteReg,ReadReg1,ReadReg2: in std_logic_vector(2 downto 0);
      WriteData:in std_logic_vector(31 downto 0);
      ReadData1,ReadData2: out std_logic_vector(31 downto 0)
      );
end component;
signal clk_TB,reset_TB, RegWrite_TB : std_logic := '0';
signal WriteReg_TB, ReadReg1_TB, ReadReg2_TB: std_logic_vector(2 downto 0) := "000";
signal WriteData_TB: std_logic_vector(31 downto 0) := (others => '0');
signal ReadData1_TB, ReadData2_TB: std_logic_vector(31 downto 0);

begin
UUT: Register_File
port map(clk =>clk_TB, reset=>reset_TB,RegWrite=>RegWrite_TB,WriteReg=>WriteReg_TB,
         ReadReg1=>ReadReg1_TB, ReadReg2=>ReadReg2_TB,WriteData=>WriteData_TB,
         ReadData1=>ReadData1_TB, ReadData2=>ReadData2_TB
         );
reset_process:process
begin
reset_TB <= '1';
wait for 20 ns;
reset_TB <= '0';
wait for 20 ns;
end process;
TB_process:process
begin

reset_TB <= '1';
wait for 20 ns;
reset_TB <= '0';
wait for 20 ns;

--Writing a value 0xAAAA_AAAA to register 1
RegWrite_TB <= '1';
WriteReg_TB <= "001";
WriteData_TB <= x"AAAAAAAA";
wait for 20 ns;
--Writing a value 0xBBBB_BBBB to register 2
WriteReg_TB <= "010";
WriteData_TB <= x"BBBBBBBB";
wait for 20 ns;
--Writing a value 0xCCCC_CCCC to register 3
WriteReg_TB <= "011";
WriteData_TB <= x"CCCCCCCC";
wait for 20 ns;

--Reading Reg1 and Reg2 Values at the same time
RegWrite_TB <= '0';
ReadReg1_TB <= "001";
ReadReg2_TB <= "010";
wait for 20 ns;
--Reading register 3 and register 1 values at the same time
ReadReg1_TB <= "011";
ReadReg2_TB <= "001";
wait for 20 ns;

--Writing to register 0, output should BE 0.
-- Register 0 should never be writeable.
-- "DEADBEEF" is basically testing if the state should be at zero
RegWrite_TB <= '1';
WriteReg_TB <= "000";
--Using Debug marker, uninitialized memory
WriteData_TB <= x"DEADBEEF";
WriteData_TB <= x"DEADBEEF";
wait for 20 ns;
--Read Register 0, SHOULD still read zero
RegWrite_TB <= '0';
ReadReg1_TB <= "000";
wait for 20 ns;
wait;
end process;
end Behavioral;

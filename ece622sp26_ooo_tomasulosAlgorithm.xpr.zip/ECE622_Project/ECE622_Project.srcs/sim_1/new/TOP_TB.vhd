----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 08:25:55 PM
-- Design Name: 
-- Module Name: TOP_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TOP_TB is
--  Port ( );
end TOP_TB;

architecture Behavioral of TOP_TB is
component TOP is
  Port (clk, reset: in std_logic;
        instructionInput:   in std_logic_vector(31 downto 0);
        instructionValid:   in std_logic);
end component;
--TB SIGNALS
signal clk_TB: std_logic:='0';
signal reset_TB: std_logic:= '0';
signal instructionInput_TB: std_logic_vector(31 downto 0):=(others =>'0');
signal instructionValid_TB: std_logic:='0';

begin

UUT:TOP
    port map(
            clk=>clk_TB,reset=>reset_TB,instructionInput=>instructionInput_TB,instructionValid=>instructionValid_TB);
            
clkProcess:
process
begin
    clk_TB  <= '0';
    wait for 10 ns;
    clk_TB  <= '1';
    wait for 10 ns;
end process;

simuProcess:
process
begin
    reset_TB    <= '1';
    wait for 20 ns;
    reset_TB    <= '0';
    wait for 20 ns;
    --ADDI x1,x0,10; immediate, executes fast
    --> [(immediate)(rs1)(funct3)(rd)(opcode)]
    --[(12 bits)(5 bits)(3 bits) (5 bits)(7 bits)] => 32 bits
    --opcode = 0010011 is (7 bits)
    --rd = x1(00001) is (5 bits)
    --rs1= x0(00000) is (5 bits)
    --immediate 10 -> 0000_0000_0101 is (12 bits)
    --funct3 = 0 is (3 bits)
    --00000000101_00000_000_000001_0010011
    instructionValid_TB <= '1';
    instructionInput_TB <= "00000000101000000000000010010011";
    wait for 20 ns;
    --LW x2,0(x1); load from address x1, depends on x1 being ready
    --000000000000_00001_010_00010_0000011
    instructionInput_TB <= "00000000000000001010000100000011";
    wait for 20 ns;
    --ADD x3,x1,x2; depends on both x1 and x2 being ready
    --[(funct7)(rs2)(rs1)(funct3)(rd)(opcode)]
    -->[(7 bits)(5 bits)(5 bits)(3 bits)(5 bits)(7 bits)]
    --0000000_00010_00001_000_00011_0110011
    instructionInput_TB <= "00000000001000001000000110110011";
    wait for 20 ns;
    instructionValid_TB <=  '0';
    wait for 200 ns; 
    wait;
end process;

end Behavioral;
